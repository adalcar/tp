﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TPC3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Level Basic : Start slow, jump high
            // ----------------------------------------------------------------

            //Exercices._1___Basics.ex1.run();
            //Exercices._1___Basics.ex2.run();
            //Exercices._1___Basics.ex3.run();
            //Exercices._1___Basics.ex4.run();

            // Level Intermediate : Moar fun is comming young padawan
            // ----------------------------------------------------------------

            //Exercices._2___Intermediate.ex1.run();
            //Exercices._2___Intermediate.ex2.run();

            // Level Advanced : Go on and master the art of debugging
            // ----------------------------------------------------------------

            //Exercices._3___Advanced.crypto_box my_crypto_box = new Exercices._3___Advanced.crypto_box();
            //Console.WriteLine(my_crypto_box.get_clear_text());

            // Only the bests can survive.
            //Exercices._3___Advanced.bomb_interface my_bomb = new Exercices._3___Advanced.bomb_interface();

            // happy numbers, fun calculations
            // Exercices.Happy.checkHappy();
            Exercices.pascalCalcs.pascal(45);

        }
    }
}
