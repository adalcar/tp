If you don't know how to code, at least know ow to debug

the bullshit is strong with this one