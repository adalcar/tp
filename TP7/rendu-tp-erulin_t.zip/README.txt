1: La personne qui a ecrit le premier programme ferait bien
  de faire "goodbye world" avant de se pendre avec un cable LAN
2: ma fonction printMe contient une classe "house" a part contenant la def de la maison