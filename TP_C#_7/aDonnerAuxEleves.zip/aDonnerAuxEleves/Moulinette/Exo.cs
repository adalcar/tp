﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;
using System.IO;


namespace Moulinette
{
    class Exo
    {
        //FIX ME

        public Exo(string folderName) {
            //FIX ME
        }

        public bool execute() {
            //FIX ME
            return true;
        }
    }
}
