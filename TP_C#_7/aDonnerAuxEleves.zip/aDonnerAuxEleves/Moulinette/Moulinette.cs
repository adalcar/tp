﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace Moulinette
{
    class Moulinette
    {
        //FIX ME

        public Moulinette() {
            //FIX ME
        }

        public bool init() {
            //FIX ME
            return true;
        }

        public void execute() {
            //FIX ME
        }
    }
}
