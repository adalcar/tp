﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Moulinette
{
    class Correction
    {
        //FIX ME

        public Correction(string folderName) {
            //FIX ME
        }

        public bool init() {
            //FIX ME
            return true;
        }
    }
}
