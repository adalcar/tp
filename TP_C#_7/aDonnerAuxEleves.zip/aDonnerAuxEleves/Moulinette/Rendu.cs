﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace Moulinette
{
    class Rendu
    {
        //FIX ME

        public Rendu(string folderName) {
            //FIX ME
        }

        public bool init() { 
            //FIX ME
            return true;
        }

        public int runCorrection(List<Correction> listCorrection) {
            //FIX ME
            return 0;
        }
    }
}
