﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTF
{
    class ExA : ExX
    {
        #region constructor
        public ExA()
            : base("ExA")
        {

        }
        #endregion

        #region methods
        public override string solve(string question)
        {
            return "-1";
        }
        #endregion
    }
}
