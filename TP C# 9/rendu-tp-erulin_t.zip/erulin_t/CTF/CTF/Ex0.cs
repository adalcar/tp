﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTF
{
    class Ex0 : ExX
    {
        #region constructor
        public Ex0()
            : base("Ex0")
        {

        }
        #endregion

        #region methodes
        public override string solve(string question)
        {
            return "Salut le Monde !";
        }
        #endregion
    }
}
