﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackToBasics
{
    class mutant : Pony
    {
        private int nb_pattes;
        private int nb_tetes;
        public mutant(ConsoleColor color)
            : base(color)
        {
            
        }

    }
}
