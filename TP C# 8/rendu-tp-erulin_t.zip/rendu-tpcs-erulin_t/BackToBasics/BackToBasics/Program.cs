﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackToBasics
{
    class Program
    {
        int time;
        List<Farm> farms;
        static void Main(string[] args)
        {

            Console.Read();

        }
        void start()
        {
            time = 0;
        }
        public void update()
        {

        }
    }
}
